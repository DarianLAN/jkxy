// $(function(){
// 	$('.more').mouseover(function(){
// 		$('.headMore').slideDown().fadeIn();
// 	})
// 	$('.headMore').mouseleave(function(){
// 		$('.headMore').slideUp().fadeOut();
// 	});
// 	$('#tabs').tabs();
// })
$(function(){
	$('.more').mouseover(function(){
		$('.headMore').slideDown().fadeIn();
	});
	$('.headMore').mouseleave(function(){
		$('.headMore').slideUp().fadeOut();
	});
	tabClick.init();
	
});

//以下使用了工厂模式，感觉工厂模式应该适用于比较复杂的对象，用在这个地方反而让代码变得
//累赘复杂了，毕竟本来只是jquery中一句代码的工作量。
var tabClick = {
	init:function(){//初始化
		var me=this;
		me.lis=$('#tabs>ul>li');
		me.guanzhu();

	},
	active:function(arg){//内部功能函数
		var me=this;

		for(var i=0;i<me.lis.length;i++){
			$(me.lis[i]).removeClass('active')
		}
		$(me.lis[arg]).addClass('active')
	},
	load:function(){//内部功能函数
		$('#tabs-1').hide();
		$('#tabs-2').hide();
		$('#tabs-3').hide();
		$('#tabs-4').hide();
		$('#tabs-5').hide();
	},
	guanzhu:function(){//各项功能
		var me=this;
		me.load();
		me.active(0);
		$('#tabs-1').show();
	},
	tuijian:function(){
		var me=this;
		me.load();
		me.active(1);
		$('#tabs-2').show();
	},
	daohang:function(){
		var me=this;
		me.load();
		me.active(2);
		$('#tabs-3').show();
	},
	shipin:function(){
		var me=this;
		me.load();
		me.active(3);
		$('#tabs-4').show();
	},
	gouwu:function(){
		var me=this;
		me.load();
		me.active(4);
		$('#tabs-5').show();
	},
	factory:function(arg){//对外入口
		var me=this;
		return  me[arg]();
	}
};

